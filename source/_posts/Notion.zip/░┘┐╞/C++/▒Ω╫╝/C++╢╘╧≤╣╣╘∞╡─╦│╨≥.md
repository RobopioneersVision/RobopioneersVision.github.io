# C++对象构造的顺序

[http://blog.chinaunix.net/uid-20109769-id-2105532.html](http://blog.chinaunix.net/uid-20109769-id-2105532.html)