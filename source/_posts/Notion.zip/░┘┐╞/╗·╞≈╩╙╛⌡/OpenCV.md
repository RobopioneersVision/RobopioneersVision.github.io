# OpenCV

[OpenCV 4 图像与视频的保存](OpenCV/OpenCV 4 图像与视频的保存.md)

[C++上Opencv RotatedRect类中的points、angle、width、height等详解](OpenCV/C++上Opencv RotatedRect类中的points、angle、width、height.md)

[图像识别在C++上的实现](OpenCV/图像识别在C++上的实现.md)

[Opencv RotatedRect类中的points、angle、width、height等详解](OpenCV/Opencv RotatedRect类中的points、angle、width、height等详解.md)

[OpenCV getStructuringElement函数](OpenCV/OpenCV getStructuringElement函数.md)

[高级的形态学变换](OpenCV/高级的形态学变换.md)

[OpenCV的tips](OpenCV/OpenCV的tips.md)

