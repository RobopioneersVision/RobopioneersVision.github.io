#!/bin/bash

redis-server /home/lightning/桌面/RocketMQ/redis.conf
