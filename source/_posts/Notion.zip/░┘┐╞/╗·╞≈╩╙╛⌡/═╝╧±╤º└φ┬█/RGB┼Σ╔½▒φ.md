# RGB配色表

[http://www.wahart.com.hk/rgb.htm](http://www.wahart.com.hk/rgb.htm)