#!/bin/bash

cd /home/lightning/Aplications/RocketMQ
nohup sh bin/mqnamesrv -c /home/lightning/桌面/RocketMQ/mqnamesrv.properties > /dev/null 2> /dev/null &
nohup sh bin/mqbroker -n localhost:5000 > /dev/null 2> /dev/null &
#export NAMESRV_ADDR=localhost:5000
#cd Tools
#nohup java -jar rocketmq-console-ng-2.0.0.jar --server.port=5002 > /usr/local/bin/RocketMQ/Tools/console.log.txt &
