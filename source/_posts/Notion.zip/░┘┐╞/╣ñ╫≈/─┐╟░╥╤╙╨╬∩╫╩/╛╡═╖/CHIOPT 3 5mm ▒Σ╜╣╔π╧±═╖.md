# CHIOPT 3.5mm 变焦摄像头

分布: 1个位于库存
型号: FA0401C
备注: 视野广阔但图像尤其是边缘图像变形严重。
数量: 1
标签: 广角
焦距: 3.5mm
详情: https://www.notion.so/3c03ca2c5def47fc8e542fe5265e5e40
详情页: http://www.chiopt.com/product/78.html