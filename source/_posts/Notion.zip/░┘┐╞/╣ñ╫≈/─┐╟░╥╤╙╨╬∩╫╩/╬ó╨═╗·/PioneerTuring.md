# PioneerTuring

位置: 哨兵上云台
无线调试: Yes
问题: 串口排针倾斜但不影响使用