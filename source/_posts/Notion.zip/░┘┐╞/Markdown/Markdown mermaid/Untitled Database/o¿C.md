# o–

1: 3
Inheritance 继承: Aggregation 聚合