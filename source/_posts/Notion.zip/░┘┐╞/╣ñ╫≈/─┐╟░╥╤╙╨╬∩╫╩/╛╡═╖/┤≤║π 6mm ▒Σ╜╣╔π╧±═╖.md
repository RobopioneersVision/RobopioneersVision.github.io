# 大恒 6mm 变焦摄像头

分布: 1个位于2021步兵i，1个位于库存
型号: HN-0612-2M-C1/2X
备注: 距离6m处仍能保持灯条较好的几何特征。进光量较大，2500us的曝光时间已能保证画面不甚昏暗。
数量: 2
标签: 常规
焦距: 6mm
详情: https://www.notion.so/c973edf94d6c44509390db0ad657a60f
详情页: https://www.daheng-imaging.com/products/ProductDetails.aspx?current=2&productid=3497