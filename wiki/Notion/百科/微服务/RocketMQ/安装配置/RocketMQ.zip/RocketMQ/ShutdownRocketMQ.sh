#!/bin/bash

cd /home/lightning/Aplications/RocketMQ
bin/mqshutdown broker
bin/mqshutdown namesrv
