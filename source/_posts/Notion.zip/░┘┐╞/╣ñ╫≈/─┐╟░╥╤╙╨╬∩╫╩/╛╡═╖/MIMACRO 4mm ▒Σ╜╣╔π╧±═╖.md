# MIMACRO 4mm 变焦摄像头

分布: 1个位于英雄实验机，1个位于展品步兵，1个位于哨兵下云台，1个位于库存
型号: HC-0420-5M
备注: 距离4m处能保持灯条较好的几何特征。10000us的曝光时间足以保证画面不甚昏暗。
数量: 4
标签: 广角
焦距: 4mm
详情: https://www.notion.so/954d00f005e84b518bf3d8c5466338f4
详情页: http://www.mimacro.cn/index.php?case=archive&act=list&catid=17