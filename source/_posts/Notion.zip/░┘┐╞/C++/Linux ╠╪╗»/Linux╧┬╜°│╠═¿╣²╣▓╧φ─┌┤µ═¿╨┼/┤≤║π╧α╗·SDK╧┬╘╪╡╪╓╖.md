# 大恒相机SDK下载地址

Linux ARM64版：

[http://gb.daheng-imaging.com/EN/Software/Cameras/Linux/Galaxy_Linux-armhf_Gige-U3_32bits-64bits_1.3.1911.9271.tar.gz](http://gb.daheng-imaging.com/EN/Software/Cameras/Linux/Galaxy_Linux-armhf_Gige-U3_32bits-64bits_1.3.1911.9271.tar.gz)

Linux x86_64版：

[http://gb.daheng-imaging.com/CN/Software/Cameras/Linux/Galaxy_Linux-x86_Gige-U3_32bits-64bits_1.2.1911.9122.tar.gz](http://gb.daheng-imaging.com/CN/Software/Cameras/Linux/Galaxy_Linux-x86_Gige-U3_32bits-64bits_1.2.1911.9122.tar.gz)

Mac x86_64版：

[http://gb.daheng-imaging.com/CN/Software/Cameras/Mac/galaxy_mac_cn_64bits_1.0.2004.8222.rar](http://gb.daheng-imaging.com/CN/Software/Cameras/Mac/galaxy_mac_cn_64bits_1.0.2004.8222.rar)

Windows x86_64版：

[http://gb.daheng-imaging.com/EN/Software/Cameras/Windows/Galaxy_Windows_EN_32bits-64bits_1.11.2010.9171.rar](http://gb.daheng-imaging.com/EN/Software/Cameras/Windows/Galaxy_Windows_EN_32bits-64bits_1.11.2010.9171.rar)