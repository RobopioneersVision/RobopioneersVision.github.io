# Minimal support for garbage collection and reachability-based leak detection

N1610: http://www.open-std.org/jtc1/sc22/wg21/docs/papers/2008/n2670.htm
Yes: No