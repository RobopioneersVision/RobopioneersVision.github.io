# –

1: 5
Inheritance 继承: Link (Solid) 连接（实线）