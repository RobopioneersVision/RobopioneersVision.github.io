# Linux 特化

[Linux下进程通过共享内存通信](Linux 特化/Linux下进程通过共享内存通信.md)

[Linux 多进程共享内存数据](Linux 特化/Linux 多进程共享内存数据.md)

[Linux驱动之串口（UART）](Linux 特化/Linux驱动之串口（UART）.md)

[通信协议相关](Linux 特化/通信协议相关.md)