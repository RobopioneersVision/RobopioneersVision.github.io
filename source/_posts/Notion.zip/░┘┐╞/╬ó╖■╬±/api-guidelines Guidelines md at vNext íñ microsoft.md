# api-guidelines/Guidelines.md at vNext · microsoft/api-guidelines

[https://github.com/Microsoft/api-guidelines/blob/vNext/Guidelines.md#7-consistency-fundamentals](https://github.com/Microsoft/api-guidelines/blob/vNext/Guidelines.md#7-consistency-fundamentals)